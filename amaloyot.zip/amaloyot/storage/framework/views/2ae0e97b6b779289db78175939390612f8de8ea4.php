
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('type.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <select name="cat_id" class="form-control">
    <option value="1">---</option>
        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->cat); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="number" name="price" class="form-control" placeholder="price">
    <input type="text" name="type" class="form-control" placeholder="type"><br>
    <input type="submit" value="submit" class="btn btn-info">
    <a href="<?php echo e(route('type.index')); ?>" class="btn btn-dark">prew</a>
    
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/type/create.blade.php ENDPATH**/ ?>