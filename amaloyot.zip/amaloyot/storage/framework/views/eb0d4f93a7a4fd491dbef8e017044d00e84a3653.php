
<?php $__env->startSection('content'); ?>
<table class="table">
  <thead class="table table-info">
    <tr>
        <th>
                No
        </th>
        <th>
                Name
        </th>
        <th>
                Price
        </th>
        <th>
                Categorys
        </th>
        <th>
            <a href="<?php echo e(route('type.create')); ?>">
                <i class="fas fa-2x fa-plus">
                    
                </i>
            </a>
        </th>
    </tr>
  </thead>
  <tbody class="table table-premium">
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
            <td>
                <?php echo e($loop->iteration); ?>

            </td>
            <td>
                <?php echo e($type->type); ?>

            </td>
            <td>
                <?php echo e($type->price); ?>

            </td>
            <td>
                <?php echo e($type->cats->cat); ?>

            </td>
            <td>
                <a href="">
                    <i class="fas fa-2x fa-edit">
    
                    </i>
                </a>
            </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\amaloyot\resources\views/type/index.blade.php ENDPATH**/ ?>